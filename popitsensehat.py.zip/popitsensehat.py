from sense_hat import SenseHat
sense = SenseHat()
import random
import time
r = 0
g = 0
b = 0
sense.clear(r, g, b)
popstate = 0
sense.set_pixel(3, 3, 0, 255, 0)
mili = 0
print("Start (Green)")
print("Mili State", mili)
dummy = random.randint(3, 1000)
while True:
    mili = mili + 1
    for event in sense.stick.get_events():
        if event.action == "pressed":
            if event.direction == "middle":
                if popstate == 0:
                    if 2 == random.randint(0, 2):
                        popstate = 1
                        sense.set_pixel(3, 3, 255, 150, 0)
                        print("Orange")
                        print("Mili State", mili)
                        dummy = random.randint(3, 1000)
                if popstate == 1:
                    if 1 == random.randint(0, 2):
                        popstate = 2
                        sense.set_pixel(3, 3, 255, 0, 0)
                        print("Red")
                        print("Mili State", mili)
                        dummy = random.randint(3, 1000)
                if popstate == 2:
                    if event.action == "pressed":
                        popstate = 3
                        dummy = random.randint(3, 1000)
                        poop = 0
                if popstate == 3:
                    if poop == 1:
                        r = 255
                        g = 0
                        b = 0
                        sense.clear(r, g, b)
                        time.sleep(1)
                        print("Game Over")
                        print("Mili State", mili)
                        sense.show_message("Game Over")
                        r = 0
                        g = 0
                        b = 0
                        speed = 0.01
                        sense.clear(r, g, b)
                        while not r == 255:
                            r = r + 1
                            sense.clear(r, g, b)
                            time.sleep(0.01)
                        while True:
                            while not g == 255:
                                g = g + 1
                                sense.clear(r, g, b)
                                time.sleep(0.01)
                            while not r == 0:
                                r = r - 1
                                sense.clear(r, g, b)
                                time.sleep(0.01)
                            while not b == 255:
                                b = b + 1
                                sense.clear(r, g, b) 
                                time.sleep(0.01)
                            while not g == 0:
                                g = g - 1
                                sense.clear(r, g, b)
                                time.sleep(0.01)
                            while not r == 255:
                                r = r + 1
                                sense.clear(r, g, b)
                                time.sleep(0.01)
                            while not b == 0:
                                b = b - 1
                                sense.clear(r, g, b)
                                time.sleep(0.01)
                    if not poop == 1:
                        poop = 1